r"""
Calc-Ultra is a calculus calculator. Supports calculus and linear algebra calculations!

"""