r"""
calc_ultra is a multi-functional, user-friendly

calculus calculator. Import main from calc_ultra

and calculate away!

"""